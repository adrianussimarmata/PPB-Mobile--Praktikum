package com.example.klasemen_liga_1;

public class DataKlub {

    private int peringkat;
    private String namaKlub;
    private int Poin;

    public DataKlub(int peringkat, String namaKlub, int poin) {
        this.peringkat = peringkat;
        this.namaKlub = namaKlub;
        Poin = poin;
    }

    public int getPeringkat() {
        return peringkat;
    }

    public void setPeringkat(int peringkat) {
        this.peringkat = peringkat;
    }

    public String getNamaKlub() {
        return namaKlub;
    }

    public void setNamaKlub(String namaKlub) {
        this.namaKlub = namaKlub;
    }

    public int getPoin() {
        return Poin;
    }

    public void setPoin(int poin) {
        Poin = poin;
    }
}
