package com.example.klasemen_liga_1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

//    private final ArrayList<DataKlub> klasemenLiga = new ArrayList<>();
    private RecyclerView recyclerView;
    String peringkat[], namaklub[], poin_klub[];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        DataKlub dataKlub1 = new DataKlub(1, "Bali United", 69);
//        klasemenLiga.add(dataKlub1);
//
//        DataKlub dataKlub2 = new DataKlub(2, "Persib", 66);
//        klasemenLiga.add(dataKlub2);
//
//        DataKlub dataKlub3 = new DataKlub(3, "Persebaya", 59);
//        klasemenLiga.add(dataKlub3);
//
//        DataKlub dataKlub4 = new DataKlub(4, "Bhayangkara", 59);
//        klasemenLiga.add(dataKlub4);
//
//        DataKlub dataKlub5 = new DataKlub(5, "Arema", 58);
//        klasemenLiga.add(dataKlub5);

        recyclerView = findViewById(R.id.recycler_view);
        peringkat = getResources().getStringArray(R.array.peringkat);
        namaklub = getResources().getStringArray(R.array.nama_club);
        poin_klub = getResources().getStringArray(R.array.poin_club);

        MyAdapter myAdapter = new MyAdapter(peringkat, namaklub, poin_klub, this);
        recyclerView.setAdapter(myAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

//        myAdapter = new MyAdapter(this, klasemenLiga);
//        recyclerView.setAdapter(myAdapter);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));


    }
}