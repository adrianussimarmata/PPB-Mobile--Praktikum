package com.example.klasemen_liga_1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    String peringkat[], namaklub[], poin[];
    Context context;

    public MyAdapter(String peringkat[], String namaklub[], String poin[], Context context) {
        this.peringkat = peringkat;
        this.namaklub = namaklub;
        this.poin = poin;
        this.context = context;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.club_item, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.text1.setText(peringkat[position]);
        holder.text2.setText(namaklub[position]);
        holder.text3.setText(poin[position]);
    }

    @Override
    public int getItemCount() {
        return peringkat.length;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView text1, text2, text3;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            text1 = itemView.findViewById(R.id.text_peringkat);
            text2 = itemView.findViewById(R.id.text_nama_klub);
            text3 = itemView.findViewById(R.id.text_poin_klub);
        }

        @Override
        public void onClick(View view) {
            int mPosition = getLayoutPosition();

        }
    }

    //    private final ArrayList<DataKlub> klasemenLiga;
//    private LayoutInflater mInflater;
//
//    public MyAdapter(Context context, ArrayList<DataKlub> listKlasemen) {
//        mInflater = LayoutInflater.from(context);
//        this.klasemenLiga = listKlasemen;
//    }
//
//    @NonNull
//    @Override
//    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View itemView = mInflater.inflate(R.layout.club_item, parent, false);
//        return new MyViewHolder(itemView, this);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
//        DataKlub dataKlub = klasemenLiga.get(position);
//        holder.peringkat.setText(dataKlub.getPeringkat());
//        holder.nama_klub.setText(dataKlub.getNamaKlub());
//        holder.poin_klub.setText(dataKlub.getPoin());
//    }
//
//    @Override
//    public int getItemCount() {
//        return klasemenLiga.size();
//    }
//
//    public class MyViewHolder extends RecyclerView.ViewHolder {
//        TextView peringkat;
//        TextView nama_klub;
//        TextView poin_klub;
//        MyAdapter mAdapter;
//
//        public MyViewHolder(@NonNull View itemView, MyAdapter myAdapter) {
//            super(itemView);
//            peringkat = itemView.findViewById(R.id.text_peringkat);
//            nama_klub = itemView.findViewById(R.id.text_nama_klub);
//            poin_klub = itemView.findViewById(R.id.text_poin_klub);
//            this.mAdapter = myAdapter;
//        }
//    }
}
